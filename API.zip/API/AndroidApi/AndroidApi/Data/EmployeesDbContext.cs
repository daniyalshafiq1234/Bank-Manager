﻿using AndroidApi.Model.Entities;
using Microsoft.EntityFrameworkCore;

namespace AndroidApi.Data
{
    public class EmployeesDbContext : DbContext
    {
        public EmployeesDbContext(DbContextOptions options) : base(options)
        {

        }

        public DbSet<Employees> employees { get; set; }
    }
}
