﻿using AndroidApi.Data;
using AndroidApi.Model.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;

namespace AndroidApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EmployeesController : Controller
    {
        private readonly EmployeesDbContext employeeDbContext;

        public EmployeesController(EmployeesDbContext NodesDbContext)
        {
            this.employeeDbContext = NodesDbContext;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllNodes()
        {
            return Ok(await employeeDbContext.employees.ToListAsync());

        }


        [HttpGet]
        [Route("{id:Guid}")]
        [ActionName("GetNodeById")]
        public async Task<IActionResult> GetNodeById([FromRoute] Guid id)
        {
            var note = await employeeDbContext.employees.FindAsync(id);
            if (note == null)
            {
                return NotFound();
            }
            return Ok(note);
        }

        [HttpPost]
        public async Task<IActionResult> AddNote(Employees note)
        {
           
            note.Id = Guid.NewGuid();
            await employeeDbContext.employees.AddAsync(note);
            await employeeDbContext.SaveChangesAsync();

            return CreatedAtAction(nameof(GetNodeById), new { id = note.Id }, note);
        }

        [HttpPut]
        [Route("{id:Guid}")]
        public async Task<IActionResult> UpdateNote([FromRoute] Guid id, [FromBody] Employees updatednote)
        {
            var existingNote = await employeeDbContext.employees.FindAsync(id);

            if (existingNote == null)
            {
                return NotFound();
            }
            existingNote.Name = updatednote.Name;
            existingNote.Email = updatednote.Email;
            existingNote.Age = updatednote.Age;
            existingNote.Balance = updatednote.Balance;
            existingNote.NumberOfTransaction = updatednote.NumberOfTransaction;

            await employeeDbContext.SaveChangesAsync();

            return Ok(existingNote);
        }

        [HttpDelete]
        [Route("{id:Guid}")]
        public async Task<IActionResult> DeleteNote([FromRoute] Guid id, [FromBody] Employees updatednote)
        {
            var existingNote = await employeeDbContext.employees.FindAsync();
            if (existingNote == null)
            {
                return NotFound();
            }

            employeeDbContext.employees.Remove(existingNote);
            await employeeDbContext.SaveChangesAsync();

            return Ok();
        }
    }
}



