package com.example.bankmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private void addData(Intent myIntent){
        myIntent.putExtra("key", 5); //Optional parameters
    }

    public void goToAnActivity(View v){
        Intent myIntent = new Intent(MainActivity.this, com.example.bankmanager.MainSignUpActivity.class);
        addData(myIntent);
        startActivity(myIntent);
    }
}