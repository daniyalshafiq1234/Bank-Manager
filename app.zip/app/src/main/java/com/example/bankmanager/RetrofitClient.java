package com.example.bankmanager;

import retrofit.RestAdapter;

public class RetrofitClient {

    public static com.example.bankmanager.Api getClient()
    {
        String localHost = "https://localhost:7021/swagger/";
        RestAdapter adapter = new RestAdapter.Builder()
                .setEndpoint(localHost) .build();
        com.example.bankmanager.Api api = adapter.create(com.example.bankmanager.Api.class);
        return api; // return the APIInterface object
    }
}
