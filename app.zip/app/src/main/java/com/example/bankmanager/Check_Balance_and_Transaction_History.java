package com.example.bankmanager;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Check_Balance_and_Transaction_History extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.check_balance_and_history_trans);

    }
}