package com.example.bankmanager.ModelResponse;

public class LoginResponse
{

    public String name ;
    public int age ;
    public int balance ;
    public String email ;
    public String password ;
    public int NumberOfTransaction ;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getNumberOfTransaction() {
        return NumberOfTransaction;
    }

    public void setNumberOfTransaction(int numberOfTransaction) {
        NumberOfTransaction = numberOfTransaction;
    }

    public LoginResponse(String name, int age, int balance, String email, String password, int numberOfTransaction)
    {
        this.name = name;
        this.age = age;
        this.balance = balance;
        this.email = email;
        this.password = password;
        NumberOfTransaction = numberOfTransaction;
    }
}
