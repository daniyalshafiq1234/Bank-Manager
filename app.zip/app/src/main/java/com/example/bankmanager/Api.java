package com.example.bankmanager;

import com.example.bankmanager.ModelResponse.LoginResponse;
import com.example.bank.ModelResponse.SignUpResponse;

import java.util.List;

import retrofit.Callback;
import retrofit.http.DELETE;
import retrofit.http.Field;
import retrofit.http.GET;
import retrofit.http.POST;
import retrofit.http.Path;

public interface Api {

    @POST("/api/employees/{id}")
    public void registration(@Field("name") String name,
                             @Field("email") String email,
                             @Field("password") String password,
                             @Field("age") int age ,
                             @Field("balance") int balance,
                             @Field("NumberOfTransaction") int NumberOfTransaction,
                             Callback<SignUpResponse> callback);

    @POST("/api/employees/{id}")
    public void login(@Field("name") String name,
                             @Field("email") String email,
                             @Field("password") String password,
                             @Field("age") int age ,
                             @Field("balance") int balance,
                             @Field("NumberOfTransaction") int NumberOfTransaction,
                             Callback<LoginResponse> callback);

    @DELETE("/api/employees/{id}")
    void deleteItem(@Path("id") int itemId, Callback<LoginResponse> callback);

    @GET("/api/employees")
    Callback<List<LoginResponse>> getData();
}