package com.example.bankmanager;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class TransferPayment extends AppCompatActivity {

    EditText edittext;
    EditText edittext2;
    EditText edittext3;
    private int BankName;
    private int recipNumber;
    private int amount;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transfer_and_payment);
        edittext = (EditText) findViewById(R.id.editTextTextPersonName2);
        edittext.setOnKeyListener(new View.OnKeyListener(){

            @Override
            public boolean onKey(View v, int i, KeyEvent keyEvent) {
                BankName = i;
                return true;
            }
        });

        edittext2 = (EditText) findViewById(R.id.editTextPhone);
        edittext2.setOnKeyListener(new View.OnKeyListener(){

            @Override
            public boolean onKey(View v, int i, KeyEvent keyEvent) {
                recipNumber = i;
                return true;
            }
        });

        edittext3 = (EditText) findViewById(R.id.editTextPhone2);
        edittext3.setOnKeyListener(new View.OnKeyListener(){

            @Override
            public boolean onKey(View v, int i, KeyEvent keyEvent) {
                amount = i;
                return false;
            }
        });
    }

}
