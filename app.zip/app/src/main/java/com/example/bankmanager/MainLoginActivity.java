package com.example.bankmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.bankmanager.ModelResponse.LoginResponse;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class MainLoginActivity extends AppCompatActivity
{
    LoginResponse LOginResponse;
    EditText password, name;
    Button login;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        name = (EditText) findViewById(R.id.name);
        password = (EditText) findViewById(R.id.password);
        login = (Button) findViewById(R.id.login);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkName() && checkpassword() ) {
                    LoggedIn();
                    Intent i = new Intent(MainLoginActivity.this , MainSignUpActivity.class);
                }
            }
        });
    }

    private boolean checkName()
    {
        String TempName = name.getText().toString();

        if(!TempName.isEmpty())
        {
            return true;
        }

        name.setError("Please Enter Proper Name");
        name.requestFocus();
        return false;
    }

    private boolean checkpassword()
    {
        String Temppassword = password.getText().toString();

        if(!Temppassword.isEmpty())
        {
            return true;
        }

        password.setError("Please Enter Proper Password");
        password.requestFocus();
        return false;
    }

    private void LoggedIn()
    {
        final ProgressDialog progressDialog = new ProgressDialog(MainLoginActivity.this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please Wait");
        progressDialog.show();

        RetrofitClient.getClient().login(name.getText().toString().trim(),
                "osama@uni.com",
                password.getText().toString().trim(),18,0,0,
                new Callback<LoginResponse>()
                {
                    @Override
                    public void success(LoginResponse loginResponse, Response response)
                    {
                        progressDialog.dismiss();
                        LOginResponse = loginResponse;
                        Toast.makeText(MainLoginActivity.this,"You have Successfully LoggedIn" ,Toast.LENGTH_SHORT ).show();
                    }

                    @Override
                    public void failure(RetrofitError error)
                    {
                        Toast.makeText(MainLoginActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                        progressDialog.dismiss();
                    }
                });
    }

}