package com.example.bankmanager;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.bank.ModelResponse.SignUpResponse;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class MainSignUpActivity extends AppCompatActivity
{
    SignUpResponse SignUpresponse;
    EditText email, password, name, rePassword;
    Button register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        name = (EditText) findViewById(R.id.username);

        email = (EditText) findViewById(R.id.email);

        password = (EditText) findViewById(R.id.password);

        rePassword = (EditText) findViewById(R.id.rePassword);

        register = (Button) findViewById(R.id.register);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkName() && checkemail() && checkpassword() && checkRepassword()) {
                    Registered();
                    Intent i = new Intent(MainSignUpActivity.this , MainLoginActivity.class);
                }
            }
        });
    }

    private boolean checkName()
    {
        String TempName = name.getText().toString();

        if(!TempName.isEmpty())
        {
            return true;
        }

        name.setError("Please Enter Proper Name");
        name.requestFocus();
        return false;
    }

    private boolean checkemail()
    {
        String Tempemail = email.getText().toString();

        if(!Tempemail.isEmpty())
        {
            return true;
        }

        email.setError("Please Enter Proper Name");
        email.requestFocus();
        return false;
    }

    private boolean checkpassword()
    {
        String Temppassword = password.getText().toString();

        if(!Temppassword.isEmpty())
        {
            return true;
        }

        password.setError("Please Enter Proper Password");
        password.requestFocus();
        return false;
    }
    private boolean checkRepassword()
    {
        String TempRepassword = rePassword.getText().toString();

        if((!TempRepassword.isEmpty()) && (TempRepassword == password.getText().toString()))
        {
            return true;
        }

        rePassword.setError("Passwords Doesn't match");
        rePassword.requestFocus();
        return false;
    }



    private void Registered()
    {
        final ProgressDialog progressDialog = new ProgressDialog(MainSignUpActivity.this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Please Wait");
        progressDialog.show();

        RetrofitClient.getClient().registration(name.getText().toString().trim(),
                email.getText().toString().trim(),
                password.getText().toString().trim(),18,0,0,
                new Callback<SignUpResponse>()
                {
                    @Override
                    public void success(SignUpResponse signUpResponse, Response response)
                    {
                        progressDialog.dismiss();
                        SignUpresponse = signUpResponse;
                        Toast.makeText(MainSignUpActivity.this,"You have Successfully Signedin" ,Toast.LENGTH_SHORT ).show();
                    }

                    @Override
                    public void failure(RetrofitError error)
                    {
                        Toast.makeText(MainSignUpActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                        progressDialog.dismiss();
                    }
                });
     }
}

